﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication1
{
    class Product2
    {
        public static int idCount { get; set; } 

        public int id { get; set; } 

        public string productName { get; set; } 

        public string productDescription { get; set; } 

        public double productPrice { get; set; } 

        public int productQty { get; set; } 

        public double amtPrice { get; set; }




    }
}
