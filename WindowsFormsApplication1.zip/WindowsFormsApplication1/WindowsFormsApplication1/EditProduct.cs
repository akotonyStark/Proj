﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class editItem : Form
    {
        Product1 product;
        //public Product Productf { get { return product; } }
        private List<Product1> productsToEdit = new List<Product1>();
        //public List<Product> ProductsToEdit { get { return productsToEdit; } set { productsToEdit = value; }  }
        string name;
        string description;
        double price;
        int quantity;
        double amountPrice;
        ViewItems viewItems = new ViewItems();

        Product1 oldProduct;

        internal List<Product1> ProductsToEdit
        {
            get
            {
                return productsToEdit;
            }

            set
            {
                productsToEdit = value;
            }
        }

        public editItem()
        {
            InitializeComponent();
            viewItems.listView1.Items.Clear();
        }



        public editItem(ViewItems v)
        {
            InitializeComponent();
            viewItems = v;
        }


        private void back2_Click(object sender, EventArgs e)
        {
            this.Hide();

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //if (NametextBox.Text == "" | MakeTextBox.Text == "" | ModeltextBox.Text == "" | YearOfMaketextBox.Text == "" | DoorstextBox.Text == "" | TransmissionComboBox.Text == "")
            //{
            //    MessageBox.Show("Please fill out all fields.");
            //}
            //else
            try
            {
                oldProduct = ProductsToEdit[0];
                product = new Product1(name, description, price, quantity, amountPrice, false);
                Inventory.UpdateProduct(oldProduct, product);
                viewItems.listView1.Items.Clear();
                viewItems.LoadData();
                this.Hide();
            }
            catch (NullReferenceException)
            {
                MessageBox.Show("Empty Inventory!");
            }
        }

        private void editItem_Load(object sender, EventArgs e)
        {

        }

        private void nameTextBox1_TextChanged(object sender, EventArgs e)
        {
            name = nameTextBox1.Text;
        }

        private void descriptionTextBox1_TextChanged(object sender, EventArgs e)
        {
            description = descriptionTextBox1.Text;

        }

        private void priceTextBox1_TextChanged(object sender, EventArgs e)
        {
            price = double.Parse(priceTextBox1.Text);
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void quantityTextBox1_TextChanged(object sender, EventArgs e)
        {
            try
            {
                quantity = int.Parse(quantityTextBox1.Text);

            }
            catch (FormatException)
            {
                MessageBox.Show("Enter a digit");
            }
           
        }
    }
}
