﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace WindowsFormsApplication1
{
    class Inventory
    {
        public static string productFile = @"D:\WindowsFormsApplication1\Inventory.txt";
        public static List<Product1> productList = new List<Product1>();
        public static List<Product2> productList2 = new List<Product2>();
        public static List<Product1> searchList = new List<Product1>();
        public static List<Product1> SortedList = new List<Product1>();
        //public static List<Product> SearchList { get { return _searchList; } set { _searchList = value; } }


        public static void addProduct(Product1 product)
        {
            productList.Add(product);
            UpdateInventoryFile(productList, false);
        }
        public static void clearInventory(ViewItems vi)
        {
            Product1.total = 0;
            Inventory.productList.Clear();
            UpdateInventoryFile(productList, false);
            
            vi.LoadData();
        }
        public static void deleteProduct(Product1 product)
        {
            Product1.total -= (product.amtPrice);
            productList.Remove(product);
            UpdateInventoryFile(productList, false);
        }


        public static void UpdateProduct(Product1 productToUpdate, Product1 productWithNewDetails)
        {
            Product1.total = ((Product1.total - productToUpdate.amtPrice) + productWithNewDetails.amtPrice);
            UpdateInventoryFile(productList, false);

            productWithNewDetails.id = productToUpdate.id;
            productToUpdate.productName = productWithNewDetails.productName;
            productToUpdate.productDescription = productWithNewDetails.productDescription;

            productToUpdate.productPrice = productWithNewDetails.productPrice;
            productToUpdate.productQty = productWithNewDetails.productQty;
            productToUpdate.amtPrice = productWithNewDetails.amtPrice;

            //public double OldTotal = Product1.total;
            
        }
        public static void UpdateQuantity(double amountToSubtract, Product1 productX, Product1 productU)
        {
            productX.productName = productU.productName;
            productX.productDescription = productU.productDescription;
            productX.productPrice = productU.productPrice;
            productX.productQty = productU.productQty;
            UpdateInventoryFile(productList, false);


















            // ViewItems vi = new ViewItems();
            //double a = double.Parse(vi.listView1.SelectedItems[0].SubItems[2].Text);
            //double b = double.Parse(vi.listView1.SelectedItems[0].SubItems[3].Text);
            //double d = (b - x);
            //double c = a * d;
            //vi.listView1.SelectedItems[0].SubItems[3].Text = string.Format("{0}", (b-x)) ;
            //vi.listView1.SelectedItems[0].SubItems[4].Text = string.Format("{0}", c);
        }


        public static string displayProductsInventory()
        {
            string products = "";
            foreach (Product1 product in productList)
            {
                products += product.ToString();
                products += "\n";

            }
            return products;
        }


        public static string displayFullInventory()
        {
            return string.Format("PRODUCTS\n{0}", displayProductsInventory());
        }

        public static void updateInventoryFromFile()
        {
            if (File.Exists(productFile))
            {
                StreamReader sr = new StreamReader(productFile);
                int id1 = 0;
                string name = string.Empty;
                string description = string.Empty;

                double price = 0.0;
                int quantity = 0;
                double totalPrice = 0.0;
                Product1 product;
                try
                {
                    Product1.idCount = int.Parse(sr.ReadLine());
                }
                catch (ArgumentNullException)
                {
                    Product1.idCount = 0;
                }
                while (!sr.EndOfStream)
                {
                    string productDetails = sr.ReadLine();
                    if (!string.IsNullOrWhiteSpace(productDetails))
                    {
                        string[] productDetailsList = productDetails.Split(',');
                        for (int i = 0; i < productDetailsList.Length; i++)
                        {
                            switch (i)
                            {
                                case 0:
                                    id1 = int.Parse(productDetailsList[i]);
                                    break;
                                case 1:
                                    name = productDetailsList[i].Trim();
                                    break;
                                case 2:
                                    description = productDetailsList[i].Trim();
                                    break;
                                case 3:
                                    price = double.Parse(productDetailsList[i]);
                                    break;
                                case 4:
                                    quantity = int.Parse(productDetailsList[i]);
                                    break;
                                case 5:
                                    totalPrice = double.Parse(productDetailsList[i]);
                                    break;
                                default:
                                    break;
                            }
                        }
                        product = new Product1(name, description, price, quantity, totalPrice, true);
                        var product2 = new Product2
                        {   
                            productName = name,
                            productDescription = description,
                            productPrice = price,
                            productQty = quantity,
                            amtPrice = totalPrice
                        };
                        product.id = id1;
                        product2.id = id1;
                        UpdateInventory(product);
                        productDetails = sr.ReadLine();
                    }
                }
                sr.Close();
            }
            else
            {
                throw new FileNotFoundException();
            }
        }


        public static void UpdateInventory(Product1 product)
        {
            Inventory.productList.Add(product);


        }


        public static void UpdateInventory2(Product2 product)
        {
            Inventory.productList2.Add(product);


        }

        public static void UpdateInventoryFile(List<Product1> productsList, bool append)
        {
            string products = "";
            StreamWriter sc = new StreamWriter(productFile, append);
            sc.WriteLine(Product1.idCount);
            foreach (Product1 product in productsList)
            {
                products += product.ToString();
                products += "\n";

            }
            sc.Write(products);
            sc.Close();
        }

        public static void UpdateSearchList(string field, string value)
        {
            searchList.Clear();
            if (field.Equals("ID"))
            {
                foreach (Product1 product in productList)
                {
                    if (product.id == int.Parse(value))
                    {
                        searchList.Add(product);
                    }
                }
            }
            else if (field.Equals("name"))
            {
                foreach (Product1 product in productList)
                {
                    if (product.productName.Contains(value))
                    {
                        searchList.Add(product);
                    }
                }
            }
            else if (field.Equals("price"))
            {
                foreach (Product1 product in productList)
                {
                    if (product.productName.Contains(value))
                    {
                        searchList.Add(product);
                    }
                }
            }
            else if (field.Equals("quantity"))
            {
                foreach (Product1 product in productList)
                {
                    if (product.productName.Contains(value))
                    {
                        searchList.Add(product);
                    }
                }
            }
            else if (field.Equals("totalPrice"))
            {
                foreach (Product1 product in productList)
                {
                    if (product.productName.Contains(value))
                    {
                        searchList.Add(product);
                    }
                }
            }

        }
        public static void SortByAscending(string field)
        {
            Product1 temp;
            SortedList = new List<Product1>(productList);
            if (field.Equals("ID"))
            {
                for (int j = 0; j <= SortedList.Count - 2; j++)
                {
                    for (int i = 0; i <= SortedList.Count - 2; i++)
                    {
                        if (SortedList[i].id > SortedList[i + 1].id)
                        {
                            temp = SortedList[i + 1];
                            SortedList[i + 1] = SortedList[i];
                            SortedList[i] = temp;
                        }
                    }
                }
            }
            else if (field.Equals("Name"))
            {
                for (int j = 0; j <= SortedList.Count - 2; j++)
                {
                    for (int i = 0; i <= SortedList.Count - 2; i++)
                    {
                        if (string.Compare(SortedList[i].productName, SortedList[i + 1].productName) > 0)
                        {
                            temp = SortedList[i + 1];
                            SortedList[i + 1] = SortedList[i];
                            SortedList[i] = temp;
                        }
                    }
                }
            }
            else if (field.Equals("Description"))
            {
                for (int j = 0; j <= SortedList.Count - 2; j++)
                {
                    for (int i = 0; i <= SortedList.Count - 2; i++)
                    {
                        if (string.Compare(SortedList[i].productDescription, SortedList[i + 1].productDescription) > 0)
                        {
                            temp = SortedList[i + 1];
                            SortedList[i + 1] = SortedList[i];
                            SortedList[i] = temp;
                        }
                    }
                }
            }

            else if (field.Equals("price"))
            {
                for (int j = 0; j <= SortedList.Count - 2; j++)
                {
                    for (int i = 0; i <= SortedList.Count - 2; i++)
                    {
                        if (SortedList[i].productPrice > SortedList[i + 1].productPrice)
                        {
                            temp = SortedList[i + 1];
                            SortedList[i + 1] = SortedList[i];
                            SortedList[i] = temp;
                        }
                    }
                }
            }
            else if (field.Equals("Quantity"))
            {
                for (int j = 0; j <= SortedList.Count - 2; j++)
                {
                    for (int i = 0; i <= SortedList.Count - 2; i++)
                    {
                        if (SortedList[i].productQty > SortedList[i + 1].productQty)
                        {
                            temp = SortedList[i + 1];
                            SortedList[i + 1] = SortedList[i];
                            SortedList[i] = temp;
                        }
                    }
                }
            }


        }

        public static void SortByDescending(string field)
        {
            Product1 temp;
            SortedList = new List<Product1>(productList);
            if (field.Equals("ID"))
            {
                for (int j = 0; j <= SortedList.Count - 2; j++)
                {
                    for (int i = 0; i <= SortedList.Count - 2; i++)
                    {
                        if (SortedList[i].id < SortedList[i + 1].id)
                        {
                            temp = SortedList[i + 1];
                            SortedList[i + 1] = SortedList[i];
                            SortedList[i] = temp;
                        }
                    }
                }
            }
            else if (field.Equals("Name"))
            {
                for (int j = 0; j <= SortedList.Count - 2; j++)
                {
                    for (int i = 0; i <= SortedList.Count - 2; i++)
                    {
                        if (string.Compare(SortedList[i].productName, SortedList[i + 1].productName) < 0)
                        {
                            temp = SortedList[i + 1];
                            SortedList[i + 1] = SortedList[i];
                            SortedList[i] = temp;
                        }
                    }
                }
            }
            else if (field.Equals("Description"))
            {
                for (int j = 0; j <= SortedList.Count - 2; j++)
                {
                    for (int i = 0; i <= SortedList.Count - 2; i++)
                    {
                        if (string.Compare(SortedList[i].productDescription, SortedList[i + 1].productDescription) < 0)
                        {
                            temp = SortedList[i + 1];
                            SortedList[i + 1] = SortedList[i];
                            SortedList[i] = temp;
                        }
                    }
                }
            }
            else if (field.Equals("Price"))
            {
                for (int j = 0; j <= SortedList.Count - 2; j++)
                {
                    for (int i = 0; i <= SortedList.Count - 2; i++)
                    {
                        if (SortedList[i].productPrice < SortedList[i + 1].productPrice)
                        {
                            temp = SortedList[i + 1];
                            SortedList[i + 1] = SortedList[i];
                            SortedList[i] = temp;
                        }
                    }
                }
            }
            else if (field.Equals("Quantity"))
            {
                for (int j = 0; j <= SortedList.Count - 2; j++)
                {
                    for (int i = 0; i <= SortedList.Count - 2; i++)
                    {
                        if (SortedList[i].productQty < SortedList[i + 1].productQty)
                        {
                            temp = SortedList[i + 1];
                            SortedList[i + 1] = SortedList[i];
                            SortedList[i] = temp;
                        }
                    }
                }
            }

        }
    }
}


























