﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication1
{
    class Product1
    {

        public static int idCount { get;  set; } = 0;

        public int id = 0;

        public  string productName = string.Empty;

        public string productDescription = string.Empty;
        
        public  double productPrice = 0;

        public int productQty = 0;
        

        public double amtPrice = 0;

        public static double total = 0;


        public Product1(string productName, string productDescription, double productPrice, int productQty, double amtPrice,  bool addIdCount = true)
        {
            if (addIdCount)
            {

                idCount++;
                total += (productQty * productPrice);
            }
            this.id = idCount;
            this.productName = productName;
            this.productDescription = productDescription;
            
            this.productPrice = productPrice;
            this.productQty = productQty;



            this.amtPrice = (productPrice*productQty);

            



        }

        public override string ToString()
        {

            return String.Format("{0}, {1}, {2}, {3}, {4}, {5}\n", productName, productDescription, productPrice, productQty, amtPrice, total);
        }


    }
}
