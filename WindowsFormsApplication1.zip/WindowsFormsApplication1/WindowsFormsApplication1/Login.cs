﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class login : Form
    {
       
        public login()
        {

            InitializeComponent();
            if (selectUserForm.manager)
            {
                pictureBox1.BackgroundImage = Image.FromFile(@"D:\WindowsFormsApplication1\WindowsFormsApplication1\pictures\admin.png");
                pictureBox1.BackgroundImageLayout = ImageLayout.Stretch;
                loginVariable.Text = "Manager";

            }
            else
            {
                pictureBox1.BackgroundImage = Image.FromFile(@"D:\WindowsFormsApplication1\WindowsFormsApplication1\pictures\manager.png");
                BackgroundImageLayout = ImageLayout.Stretch;
                loginVariable.Text = "Attendant";
            }

        }
        ViewItems view1 = new ViewItems();
        
        
        private void button1_Click(object sender, EventArgs e)
        {
           // MessageBox.Show(selectUserForm.manager.ToString() );

            if (selectUserForm.manager) {
                
                if (usernameTextBox.Text == "admin" && passwordTextBox.Text == "admin")
                {
                    this.Hide();

                    view1.Show();

                }
                else if (usernameTextBox.Text == string.Empty && passwordTextBox.Text == string.Empty)
                {
                    MessageBox.Show("Enter credentials!");
                }
                else
                {
                    MessageBox.Show("Wrong credentials! Please retry.");
                }


            }
            else
            {
                if (usernameTextBox.Text == "user" && passwordTextBox.Text == "user")
                {
                    this.Hide();

                    view1.Show();

                }
                else if (usernameTextBox.Text == string.Empty && passwordTextBox.Text == string.Empty)
                {
                    MessageBox.Show("Enter credentials!");
                }
                else
                {
                    
                    MessageBox.Show("Wrong credentials! Please retry.");
                }
               
            }




        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
         
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            selectUserForm us = new selectUserForm();
            us.Show();
        }

        private void login_Load(object sender, EventArgs e)
        {

        }

        private void loginVariable_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }
    }
}
