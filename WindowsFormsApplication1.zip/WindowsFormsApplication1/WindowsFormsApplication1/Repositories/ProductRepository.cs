﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WindowsFormsApplication1.Entities;

namespace WindowsFormsApplication1.Repositories
{
    public class ProductRepository
    {
        public Product AddProduct(Product product)
        {
            return null;
        } 


        public Product UpdateProduct(Product product)
        {
            return null;
        }


        public Product DeleteProduct(Product product)
        {
            return null;
        }

        public List<Product> AllProducts()
        {
            return null;
        }

    }
}
