﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class AddForm : Form
    {
        Product1 product;       
        string name;
        string description;
        double price;
        int quantity;
        double amountPrice;
        ViewItems VI;
        public AddForm()
        {
            InitializeComponent();
            VI.listView1.Items.Clear();
           
        }

        public AddForm(ViewItems v)
        {
            InitializeComponent();
            VI = v;
        }

        private void AddForm_Load(object sender, EventArgs e)
        {

        }

        private void addButton_Click(object sender, EventArgs e)
        {
           
            //if (nameTextBox.Text == "" | descriptionTextBox.Text == "" | priceTextBox.Text == "" | qtyTextBox.Text == "")
            //{
            //    MessageBox.Show("Please fill out all fields.");
            //}
            //else
            //{
            //    product = new Product(name, description, price, quantity);
            //    Inventory.addProduct(product);
            //    this.Hide();
            //    VI.listView1.Items.Clear();
            //    VI.LoadData();
            //    VI.Show();
                
                
            //}


        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
           // name = nameTextBox.Text;

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            //price = double.Parse(priceTextBox.Text);
        }

       

        private void backButton_Click(object sender, EventArgs e)
        {
            this.Hide();
           
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void descriptionTextBox_TextChanged(object sender, EventArgs e)
        {
           // description = descriptionTextBox.Text;
        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {
            //quantity = int.Parse(qtyTextBox.Text);
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

       
        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            try
            {
                product = new Product1(name, description, price, quantity, amountPrice);
                Inventory.addProduct(product);
                this.Hide();
                VI.listView1.Items.Clear();
                VI.LoadData();
                VI.Show();
            
            } 
                //(nameTextBox1.Text == "" | descriptionTextBox1.Text == "" | priceTextBox1.Text == "" | qtyTextBox.Text == "")
            
            catch (NullReferenceException) 
            {
                MessageBox.Show("Please fill out all fields.");


            }
        }

        private void back2_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
        private void nameTextBox1_TextChanged(object sender, EventArgs e)
        {
            name = nameTextBox1.Text;
        }

        private void descriptionTextBox1_TextChanged(object sender, EventArgs e)
        {
            description = descriptionTextBox1.Text;
        }

        private void priceTextBox1_TextChanged(object sender, EventArgs e)
        {
            try { price = double.Parse(priceTextBox1.Text); }
            catch(InvalidEnumArgumentException  ) {
                MessageBox.Show("Please enter a number");
            }
            catch (System.FormatException) {
                MessageBox.Show("Please enter a number");
            }
        }

        private void textBox1_TextChanged_2(object sender, EventArgs e)
        {
            try { quantity = int.Parse(qtyTextBox1.Text); }
            catch (System.FormatException)
            {
                MessageBox.Show("Please enter a number");
            }
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }
    }
}

