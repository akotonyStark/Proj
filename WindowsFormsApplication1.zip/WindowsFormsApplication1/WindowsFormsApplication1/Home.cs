﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class ViewItems : Form
    {
        Product1 product;
        string xname;
        string xdescription;
        double xprice;
        int xquantity;
        double xamountPrice;

        public ListViewItem productItem;
        //  public  List<Product> product;
        string sortField;
        string Details;
        string searchField;
        // public List<Product> productsToEdit = new List<Product>();
        bool descending = false;
        double total = 0;
        string totalString = string.Empty;
        double qty = 0;
        Product1 oldProduct;
        internal List<Product1> productX
        {
            get
            {
                return productX;
            }

            set
            {
                productX = value;
            }
        }



        List<Product2> productN = new List<Product2>();




        public ViewItems()
        {
            InitializeComponent();
            if (!selectUserForm.manager)
            {
                editDataButton.Hide();
            }
            totalTextBox.ReadOnly = true;
            button3.Hide();
            numericUpDown1.Hide();
            //button3.Hide();
            //numericUpDown1.Hide();

            this.LoadData();
        }


        public void LoadData()
        {

            if (listView1.Items.Count == 0)
            {

                foreach (Product1 product in Inventory.productList)
                {
                    bool unique = true;
                    // productItem = new ListViewItem(string.Format("{0}", product.id));
                    productItem = new ListViewItem(product.productName);
                    productItem.SubItems.Add(product.productDescription);
                    productItem.SubItems.Add(string.Format("{0}", product.productPrice));
                    productItem.SubItems.Add(string.Format("{0}", product.productQty));
                    productItem.SubItems.Add(string.Format("{0}", product.amtPrice));

                    foreach (var item in listView1.Items)
                    {
                        if (productItem.SubItems[0] == item)
                        {
                            unique = false;
                        }
                    }
                    if (unique)
                    {
                        listView1.Items.Add(productItem);
                    }
                    listView1.FullRowSelect = true;
                }
            }
            foreach (var item in listView1.Items)
            {
                total += double.Parse(productItem.SubItems[4].Text);
            }
        }




        ////public void LoadData(List<Product> x)
        ////{
        ////    if (listView1.Items.Count == 0)
        ////    {
        ////        foreach (Product product in x)
        ////        {
        ////            bool unique = true;
        ////            productItem = new ListViewItem(string.Format("{0}", product.id));
        ////            productItem.SubItems.Add(product.productName);
        ////            productItem.SubItems.Add(product.productDescription);

        ////            productItem.SubItems.Add(string.Format("{0}", product.productPrice));
        ////            productItem.SubItems.Add(string.Format("{0}", product.productQty));




        ////            foreach (var item in listView1.Items)
        ////            {
        ////                if (productItem.SubItems[0] == item)
        ////                {
        ////                    unique = false;
        ////                }
        ////            }
        ////            if (unique)
        ////            {
        ////                listView1.Items.Add(productItem);
        ////            }
        ////        }
        ////    }
        ////}

        private void ViewItems_Load(object sender, EventArgs e)
        {

        }

        private void goToAddForm_Click(object sender, EventArgs e)
        {

            AddForm AF = new AddForm(this);
            AF.Show();
        }


        //private void deleteDataButton_Click(object sender, EventArgs e)
        //{
        //    try
        //    {
        //        List<Product> productsToRemove = new List<Product>();
        //        foreach (Product product in Inventory.productList)
        //        {
        //            if (product.id == int.Parse(listView1.SelectedItems[0].SubItems[0].Text))
        //            {
        //                productsToRemove.Add(product);
        //            }
        //        }
        //        Inventory.deleteProduct(productsToRemove[0]);
        //        listView1.Items.Clear();
        //        this.LoadData();
        //    }
        //    catch (ArgumentOutOfRangeException f)
        //    {
        //        MessageBox.Show("Please Select An Item's ID" +"("+f+")");
        //    }

        //}

        private void editDataButton_Click(object sender, EventArgs e)
        {


            //try
            //{
            //    editItem x = new editItem();

            //    foreach (Product product in Inventory.productList)
            //    {
            //        if (product.id == int.Parse(listView1.SelectedItems[0].SubItems[0].Text))
            //        {
            //            x.ProductsToEdit.Add(product);

            //        }
            //    }
            //    x.nameTextBox1.Text = x.ProductsToEdit[0].productName;
            //    x.descriptionTextBox1.Text = x.ProductsToEdit[0].productDescription;
            //    x.priceTextBox1.Text = string.Format("{0}", x.ProductsToEdit[0].productPrice);
            //    this.Hide();
            //    x.Show();
            //}
            //catch (ArgumentOutOfRangeException)
            //{
            //    MessageBox.Show("Please select an item to edit");
            //}



        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void goToAddForm_Click_1(object sender, EventArgs e)
        {
            AddForm af = new AddForm();
            this.Hide();
            af.Show();
        }

        private void editDataButton_Click_1(object sender, EventArgs e)
        {

            //try
            //{
            //    editItem x = new editItem();

            //    foreach (Product product in Inventory.productList)
            //    {
            //        if (product.id == int.Parse(listView1.SelectedItems[0].SubItems[0].Text))
            //        {
            //            x.ProductsToEdit.Add(product);

            //        }
            //    }
            //    x.nameTextBox1.Text = x.ProductsToEdit[0].productName;
            //    x.descriptionTextBox1.Text = x.ProductsToEdit[0].productDescription;
            //    x.priceTextBox1.Text = string.Format("{0}", x.ProductsToEdit[0].productPrice);
            //    this.Hide();
            //    x.Show();
            //}
            //catch (ArgumentOutOfRangeException)
            //{
            //    MessageBox.Show("Please select an item to edit");
            //}
        }

        //private void deleteDataButton_Click_1(object sender, EventArgs e)
        //{
        //    try
        //    {
        //        List<Product> productsToRemove = new List<Product>();
        //        foreach (Product product in Inventory.productList)
        //        {
        //            if (product.id == int.Parse(listView1.SelectedItems[0].SubItems[0].Text))
        //            {
        //                productsToRemove.Add(product);
        //            }
        //        }
        //        Inventory.deleteProduct(productsToRemove[0]);
        //        listView1.Items.Clear();
        //        this.LoadData();
        //    }
        //    catch (ArgumentOutOfRangeException f)
        //    {
        //        MessageBox.Show("Please Select the ID of the item to be deleted");
        //    }
        //}


        private void goToAddForm_Click_2(object sender, EventArgs e)
        {

            AddForm AF = new AddForm(this);
            AF.Show();
        }


        private void editDataButton_Click_2(object sender, EventArgs e)
        {
            try
            {
                editItem editItem1 = new editItem(this);
                foreach (Product1 product in Inventory.productList)
                {
                    if (product.productName == listView1.SelectedItems[0].SubItems[0].Text)
                    {
                        editItem1.ProductsToEdit.Add(product);
                    }
                }
                editItem1.nameTextBox1.Text = editItem1.ProductsToEdit[0].productName;
                editItem1.descriptionTextBox1.Text = editItem1.ProductsToEdit[0].productDescription;

                editItem1.priceTextBox1.Text = string.Format("{0}", editItem1.ProductsToEdit[0].productPrice);
                editItem1.quantityTextBox1.Text = string.Format("{0}", editItem1.ProductsToEdit[0].productQty);

                //this.Hide();
                editItem1.Show();
            }
            catch (ArgumentOutOfRangeException)
            {
                MessageBox.Show("Please Select an Item to edit");
            }
            catch (FormatException)
            {
                MessageBox.Show("WTF!!");
            }

        }

        //editItem EI = new editItem(this);
        // EI.Show();

        //try
        //{
        //    editItem x = new editItem(this);
        //    x.Show();

        //    foreach (Product product in Inventory.productList)
        //    {
        //        if (product.id == int.Parse(listView1.SelectedItems[0].SubItems[0].Text))
        //        {
        //            x.ProductsToEdit.Add(product);

        //        }
        //    }
        //    x.nameTextBox1.Text = x.ProductsToEdit[0].productName;
        //    x.descriptionTextBox1.Text = x.ProductsToEdit[0].productDescription;
        //    x.priceTextBox1.Text = string.Format("{0}", x.ProductsToEdit[0].productPrice);
        //    x.quantityTextBox1.Text = string.Format("{0}", x.ProductsToEdit[0].productQty);

        //    ViewItems vp = new ViewItems();
        //    vp.LoadData();

        //}
        //catch (ArgumentOutOfRangeException)
        //{
        //    if (listView1.Items.Count == 0)
        //    {
        //        MessageBox.Show("Empty Inventory!");
        //    }
        //    else
        //    {
        //        MessageBox.Show("Please select an item to edit");
        //    }
        //}




        private void deleteDataButton_Click_2(object sender, EventArgs e)
        {
            try
            {
                List<Product1> productsToRemove = new List<Product1>();
                foreach (Product1 product in Inventory.productList)
                {
                    if (product.id == int.Parse(listView1.SelectedItems[0].SubItems[0].Text))
                    {
                        productsToRemove.Add(product);
                    }
                }
                Inventory.deleteProduct(productsToRemove[0]);
                listView1.Items.Clear();
                this.LoadData();
            }
            catch (ArgumentOutOfRangeException f)
            {
                if (listView1.Items.Count == 0)
                {
                    MessageBox.Show("Empty Inventory! ");
                }
                else

                {
                    MessageBox.Show("Please Select the ID of the item to be deleted");

                }
            }
        }



        private void panel1_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }


        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            AddForm AF = new AddForm();
            AF.Show();
        }

        private void tabPage2_Click(object sender, EventArgs e)
        {
            AddForm AF = new AddForm();
            AF.Show();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        //private void searchButton_Click(object sender, EventArgs e)
        //{

        //    try
        //    {
        //        Inventory.UpdateSearchList(searchField, Details);
        //        listView1.Items.Clear();
        //        this.LoadData1(Inventory.searchList);
        //    }
        //    catch (NullReferenceException f)
        //    {
        //        MessageBox.Show("Please select a category to sort by.");
        //    }
        //}

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            //Details = textBox1.Text;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            selectUserForm ss = new selectUserForm();
            ss.Show();
        }

        private void button1_Click_2(object sender, EventArgs e)
        {
             
            string message = "Are you sure you want to Log out?";
            string title = "Log Out";
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            DialogResult result = MessageBox.Show(message, title, buttons);
            if (result == DialogResult.Yes)
            {
                this.Hide();
                selectUserForm ss = new selectUserForm();
                ss.Show();
            }
            else
            {
                this.Close();
                ViewItems vi = new ViewItems();
                vi.Show();

            }
           
        }

        private void deleteDataButton_Click_3(object sender, EventArgs e)
        {
            try
            {
                string message = "Are you sure you want to delete this item?";
                string title = "Delete Item";
                MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                DialogResult result = MessageBox.Show(message, title, buttons);
                if (result == DialogResult.Yes)
                {

                    List<Product1> productsToRemove = new List<Product1>();
                    foreach (Product1 product in Inventory.productList)
                    {
                        if (product.productName == listView1.SelectedItems[0].SubItems[0].Text)
                        {
                            productsToRemove.Add(product);
                        }
                    }
                    Inventory.deleteProduct(productsToRemove[0]);
                    listView1.Items.Clear();
                    this.LoadData();

                }
                else
                {
                    this.Close();
                }
            }
            catch (ArgumentOutOfRangeException f)
            {
                MessageBox.Show("Please Select An Item");
            }
            catch (System.FormatException)
            {
                MessageBox.Show(" Format Exception ");
            }

        }

        //private void searchButton_Click(object sender, EventArgs e)
        //{
        //    try
        //    {
        //        if (descending)
        //        {
        //            Inventory.SortByDescending(sortField);
        //            listView1.Items.Clear();
        //            this.LoadData(Inventory.SortedList);
        //        }
        //        else
        //        {
        //            Inventory.SortByAscending(sortField);
        //            listView1.Items.Clear();
        //            this.LoadData(Inventory.SortedList);
        //        }
        //    }
        //    catch (NullReferenceException f)
        //    {
        //        MessageBox.Show("Please select a category to sort by.");
        //    }
        //}

        private void panel1_Paint_2(object sender, PaintEventArgs e)
        {

        }

        private void listView1_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            total = 0;
            totalString = string.Format("{0}", Product1.total);
            if (Product1.total == 0)
            {
                totalTextBox.Text = "0.00";
            }
            else
            {
                totalTextBox.Text = totalString;
            }


            // totalTextBox.Text = string.Format("{0}", total);
        }

        //void deleteDataBy( double qty)
        //{
        //    foreach (var item in listView1.Items)
        //    {
        //        double major = double.Parse(productItem.SubItems[3].Text);
        //        productItem.SubItems[3].Text = string.Format("{0}", major - qty);
        //        //double.Parse(productItem.SubItems[3].Text) - qty;
        //    }

        private void button3_Click(object sender, EventArgs e)
        {
            //    listView1.SelectedItems[0].SubItems[3].
            //    deleteDataBy(qty);
            try
            {

                productN = Inventory.productList2;
                //oldProduct = productX[0];
                //xname = oldProduct.productName;
                //xdescription = oldProduct.productDescription;
                //xprice = oldProduct.productPrice;
                //xquantity = oldProduct.productQty;
                var newProduct = productN.FirstOrDefault();
                var xquantity1 = xquantity - qty;
                newProduct.productQty = (int)xquantity1;

                //   product = new Product1(xname, xdescription, xprice, xquantity1, );

                //Inventory.UpdateQuantity(qty, oldProduct, product);
                //listView1.Items.Clear();
                //LoadData();
                //listView1.Items.Clear();
                this.LoadData();
            }
            catch (ArgumentOutOfRangeException)
            {
                MessageBox.Show("Please select an Item");
            }
            catch (StackOverflowException)
            {
                MessageBox.Show("WTF");
            }
            //
            //    listView1.SelectedItems[0].SubItems[3].Text = string.Format("{0}", double.Parse(listView1.SelectedItems[0].SubItems[3].Text) - qty);
            //    //listView1.Items.Clear();
            //    LoadData();
            //}catch (ArgumentOutOfRangeException)
            //{
            //   
            //



        }



        private void deleteDataByTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            qty = double.Parse(string.Format("{0}", numericUpDown1.Value));
        }

        private void clearListButton_Click(object sender, EventArgs e)
        {
            total = 0;
            Inventory.clearInventory(this);
            listView1.Items.Clear();
            Product1.total = 0;
            totalTextBox.Text = "0.00";
            totalTextBox.ForeColor = Color.Gray;

        }

        private void TotalTextBox_TextChanged(object sender, EventArgs e)
        {

        }
    }


}










//private void listView1_SelectedIndexChanged(object sender, EventArgs e)
//{

//}


